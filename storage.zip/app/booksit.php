<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class booksit extends Model
{
    //
    protected $guarded = [];
}
