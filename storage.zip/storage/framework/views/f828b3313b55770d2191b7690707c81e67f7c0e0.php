

<?php $__env->startSection('content'); ?>
    <section class="section-profile-cover section-shaped my-0">
      <!-- Circles background -->
      <img class="bg-image" src="<?php echo e(asset ('assets/img/dashboard.jpg')); ?>" style="width: 100%;">
    </section>
    <section class="section bg-secondary">
      <div class="container">
        <div class="card card-profile shadow mt--300">
          <div class="px-4">
            <div class="row justify-content-center">
              <div class="col-lg-12 text-center mt-5">
                <h2><strong>Sit Reservation</strong></h2>
                <div class="h6 font-weight-300"><i class="ni location_pin mr-2"></i>Kindly fill the form below to reserve a sit for SGTV Award Night</div>
              </div>
            </div>
            <hr>
            <div class="row justify-content-center">
              <div class="col-lg-8 mt-2 ">
                <form role="form" method="POST" action="<?php echo e(route('ticket')); ?>">
                    <div class="form-group mb-3">
                        <div class="input-group input-group-alternative">
                            <?php echo e($errors ->first('name')); ?>

                            <input class="form-control" placeholder="Fullname" type="text" name="name">
                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <div class="input-group input-group-alternative">
                          <?php echo e($errors ->first('email')); ?>

                            <input class="form-control" placeholder="Email" type="email" name="email">
                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <div class="input-group input-group-alternative">
                          <?php echo e($errors ->first('phone')); ?>

                            <input class="form-control" placeholder="Phone No" type="text" name="phone">
                        </div>
                    </div>
                    <?php if(session()->get('error')): ?>
                    <div class="alert alert-danger" role="alert" style="width: 100%;">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <strong>Whoops!</strong> <?php echo e(session()->get('error')); ?> </strong>
                    </div>
                    <?php endif; ?>
                    <?php if(session()->get('message')): ?>
                    <div class="alert alert-success" role="alert" style="width: 100%;">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <strong>Yepee!</strong> <?php echo e(session()->get('message')); ?> </strong>
                    </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                    <div class="alert alert-warning" role="alert" style="width: 100%;">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($error); ?><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary my-4">Book Now</button>
                    </div>
                    <?php echo csrf_field(); ?>
                </form> 
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </section>
    <style>
        .input-group-alternative {
            box-shadow: none; 
            border: 1px solid #eee;
            transition: box-shadow .15s ease;
        }
        @media (min-width: 1200px){
        .container {
            max-width: 1077px;
        }
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/seguupvt/voteapp.adeolaleye.com/voteapp/resources/views/bookings/index.blade.php ENDPATH**/ ?>