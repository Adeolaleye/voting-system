

<?php $__env->startSection('content'); ?>
<div class="section section-shaped pt-2 pb-0">
    <div class="shape shape-style-3 shape-default">
        <span class="span-150"></span>
    </div>
    <div class="page-header">
        <div class="container shape-container d-flex align-items-center py-lg">
            <div class="col px-0">
                <div class="row align-items-center justify-content-center">
                    <div class="col-lg-8 text-center">
                            <h3 class="display-4 font-weight-normal text-white"><?php echo e($categoryname); ?></h3>
                        <h1 class="text-white display-1">Nominees</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="section features-6">
    <div class="container">
        <form class="" method="POST" action="<?php echo e(route('vote4contestant')); ?>">
            <div class="row">
                <?php if(session()->get('error')): ?>
                <div class="alert alert-danger" role="alert" style="width: 100%;">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <strong>Whoops!</strong> <?php echo e(session()->get('error')); ?> </strong>
                </div>
                <?php endif; ?>
                <?php if(session()->get('message')): ?>
                <div class="alert alert-success" role="alert" style="width: 100%;">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <strong>Yepee!</strong> <?php echo e(session()->get('message')); ?> </strong>
                </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                <div class="alert alert-warning" role="alert" style="width: 100%;">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($error); ?><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
<?php endif; ?>
                <div class="col-lg-12">
                    
                    <?php $__currentLoopData = $contestants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contestant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check form-check-inline p-3">
                        <input class="form-check-input" type="radio" name="contestant_id" id="inlineRadio1" value="<?php echo e($contestant->id); ?>">
                        <input type="hidden" value="<?php echo e($contestant->contestantcat_id); ?>" name="contestantcat_id">
                       
                        <label class="form-check-label" for="inlineRadio1"><?php echo e($contestant->name); ?>

                            
                        </label>
            
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-lg-12 pt-4">
                    <button type="submit" class="btn btn-primary center">Cast Vote</button>
                </div>
            </div>
            <?php echo csrf_field(); ?>
        </form>
    </div>
</div>
<br />
<br />
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/seguupvt/voteapp.adeolaleye.com/voteapp/resources/views/contestantPage.blade.php ENDPATH**/ ?>