

<?php $__env->startSection('content'); ?>
    <section class="section-profile-cover section-shaped my-0" style="height: 275px">
      <!-- Circles background -->
      <img class="bg-image" src="<?php echo e(asset ('assets/img/dashboard.jpg')); ?>" style="width: 100%;">
    </section>
    <section class="section bg-secondary">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-6">
            <div class="card bg-secondary shadow border-0 mb-0 mt--220">
              <div class="card-header bg-white pb-5">
                <div class="text-muted text-center mb-1 mt-1">
                  <h2>Add Nominees</h2>
                  <small>Fill Field Appropiately</small>
                </div>
              </div>
              <div class="card-body px-lg-5 py-lg-5">
                <form role="form" method="POST" action="<?php echo e(route('addnorm')); ?>">
                    <div class="form-group mb-3">
                        <p class="text-center"><?php echo e($errors->first('contestantcategories', 'Category is required')); ?></p>
                        <?php if(session()->get('message')): ?>
                            <p class="text-center"> <?php echo e(session()->get('message')); ?> </p>
                        <?php endif; ?>
                      <select class="form-control mb-3" name="category_id">
                          <option></option>
                        <?php $__currentLoopData = $contestantcat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($categories->id); ?>"><?php echo e($categories->contestantcategories); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <input class="form-control" placeholder="Fullname" type="text" name="name">
                    </div>
                    <div class="text-center">
                      <button type="submit" class="btn btn-primary my-4">Submit</button>
                    <p><a href="result">Back To Result</a></p>
                    </div>
                    <?php echo csrf_field(); ?>
                  </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/seguupvt/vote.sgtv.tv/voteapp/resources/views/admin/addnominees.blade.php ENDPATH**/ ?>